const Discord = require('discord.js')

module.exports = {
    nome: "sorteio",
    alternativas: ["sorteio"],
    run: async(client, message, args) => {

        message.reply("Este comando está em manutenção, sinto muito.")

    }
}