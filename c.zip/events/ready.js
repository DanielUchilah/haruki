const Discord = require('discord.js')

module.exports = (client) => {

    console.log(`Olá, ${client.user.username} está online.`)

}
